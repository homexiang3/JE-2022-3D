Oriol Jimenez Ayguadé 231245 oriol.jimenez04@estudiant.upf.edu
Hong-ming Xiang Vico 229517 hongming.xiang01@estudiant.upf.edu

Link youtube:https://youtu.be/KNE_tJNXF-c

Detalles tecnicos:

Se tienen en cuenta los vectores directores a la hora de recibir los ataques, por tanto un ataque recibido por la espalda hará el doble de daño tanto a ti como a los enemigos
Hemos intentado posicionar el arma del boss de la mejor manera posible pero ha quedado un poco rara :(
Teclas de debug: 
	General:
		espacio (siguiente stage) 
	PlayStage/MultiStage:
		P (reseta el nivel)
		Right_arrow (siguiente nivel)
		T (perder vida)
		Y (bajar vida al boss)

Tenemos un modo editor que hemos usado para crear nuestros propios mapas con las siguientes opciones
	Modos
		terreno (F1) (terrenos del 1 al 3)
		cielo (F2) (cielos del 1 al 3)
		objeto (F3) (objetos del 1 al 9)
		editor (F4) (1 seleccionar 2 eliminar seleccionado 3-4 rotar 9 limpiar todas las entidades)	
		guardar (F5) (nombre del archivo por consola)
		importar mapas (F6,F7,F8 para los mapas 1 2 y 3)
	Movimiento 
		W A S D E Q	