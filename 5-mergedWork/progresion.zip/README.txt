Miembro 1: Oriol Jimenez 231245	oriol.jimenez04@estudiant.upf.edu
Miembro 2: Hong-ming Xiang 229517 hongming.xiang01@estudiant.upf.edu
Video youtube: https://youtu.be/CYaOH0evRRo

Sistemas implementados:
Stage (Espacio) - Estructura hecha pero solo hay content en PlayStage y EditorStage
Entidades
Colisiones basicas
Movimientos dinamicos - Dash(x) Salto(c)

Editor mode - De momento solo leemos y cargamos un fichero
	Importar mapa (F3 dentro del editor stage) - Se importa uno por defecto al iniciar
	Exportar mapa (F2 dentro del editor stage)
	Añadir cosas, seleccionar, rotar  (muy simple solo 1 objeto 1 fondo 1 cielo)
